rs_master=HDSP+HB+NAV
rs_header_theme=6-green
rs_header_id=header39.ini.php
rs_navigator_theme=6-green
rs_navigator_id=navColor39.ini.php
rs_background_color="#fff"

