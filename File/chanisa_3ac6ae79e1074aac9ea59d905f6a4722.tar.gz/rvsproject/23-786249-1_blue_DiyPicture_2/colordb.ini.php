[bgcolor]
color_bgn="#1fe1ff"
color_opp="#117b8b"
color_bgh="#19b4cc"
color_bgc="#63eaff"

[link]
color_anor="#20565e"
color_ahov="#f7feff"
color_acur="#bd351e"

[line]
color_line1="#138c9f"
color_line2="#95f1ff"

[bullet]
bullettone="black"