subject="Check out the [page.title]"
body="I thought you might be interested in the [page.title]You can view it at [page.url]"
