<?php
$aPageId['9d6ebcec5a5719d53c7defb5603312db']['project_page_id'] = '9d6ebcec5a5719d53c7defb5603312db';
$aPageId['9d6ebcec5a5719d53c7defb5603312db']['oldpage'] = 'Architecture.php';
$aPageId['9d6ebcec5a5719d53c7defb5603312db']['lastpage'] = 'Architecture.php';
$aPageId['d4df46172d695f0188491eea47f045f4']['project_page_id'] = 'd4df46172d695f0188491eea47f045f4';
$aPageId['d4df46172d695f0188491eea47f045f4']['oldpage'] = 'Landscape.php';
$aPageId['d4df46172d695f0188491eea47f045f4']['lastpage'] = 'Landscape.php';
$aPageId['b6d09ab2196e2e814c0219b18fb74bf6']['project_page_id'] = 'b6d09ab2196e2e814c0219b18fb74bf6';
$aPageId['b6d09ab2196e2e814c0219b18fb74bf6']['oldpage'] = 'Interior.php';
$aPageId['b6d09ab2196e2e814c0219b18fb74bf6']['lastpage'] = 'Interior.php';
$aPageId['4166281c5b1ee26e04de498bba89d07a']['project_page_id'] = '4166281c5b1ee26e04de498bba89d07a';
$aPageId['4166281c5b1ee26e04de498bba89d07a']['oldpage'] = 'Design-Studio.php';
$aPageId['4166281c5b1ee26e04de498bba89d07a']['lastpage'] = 'Design-Studio.php';
?>