[bgcolor]
color_bgn="#9AC4A1"
color_opp="#388946"
color_bgh="#6B8970"
color_bgc="#B8D6BD"
[link]
color_anor="#00540E"
color_ahov="#C7FF03"
color_acur="#00540E"
[line]
color_line1="#4D6250"
color_line2="#CDE2D0"

[bullet]
bullettone="dark"